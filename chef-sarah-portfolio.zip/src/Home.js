import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Home = () => (
  <div className='min-h-screen bg-gray-100 p-8'>
    <header className='text-center mb-8'>
      <h1 className='text-4xl font-bold'>Chef Sarah</h1>
      <p className='text-xl text-gray-600'>Culinary Expert & Cooking Show Host</p>
    </header>
    <section className='mb-8'>
      <Card className='p-4'>
        <CardContent>
          <h2 className='text-2xl font-semibold'>About Me</h2>
          <p className='mt-2'>Hello! I am Chef Sarah, a professional chef known for creating delicious and innovative dishes. With years of experience in the culinary world, I bring flavors to life through my cooking shows and live sessions.</p>
        </CardContent>
      </Card>
    </section>
    <section className='mb-8'>
      <Card className='p-4'>
        <CardContent>
          <h2 className='text-2xl font-semibold'>Signature Dishes</h2>
          <p className='mt-2'>Discover my signature recipes crafted with passion and precision, perfect for any occasion.</p>
          <Button className='mt-4'>Explore Recipes</Button>
        </CardContent>
      </Card>
    </section>
    <section>
      <Card className='p-4'>
        <CardContent>
          <h2 className='text-2xl font-semibold'>Get in Touch</h2>
          <p className='mt-2'>For collaborations, cooking sessions, or media inquiries, feel free to reach out.</p>
          <Button className='mt-4'>Contact Me</Button>
        </CardContent>
      </Card>
    </section>
  </div>
);

export default Home;
